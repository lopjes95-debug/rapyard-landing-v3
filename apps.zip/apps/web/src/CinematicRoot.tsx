import { useEffect, useRef } from "react";
import gsap from "gsap";
import FogLayer from "./layers/FogLayer";
import GridLayer from "./layers/GridLayer";
import LogoLayer from "./layers/LogoLayer";

export default function CinematicRoot() {
  const containerRef = useRef<HTMLDivElement>(null);
  const logoRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Initial reveal
      gsap.fromTo(".grid", { opacity: 0 }, { opacity: 0.25, duration: 2 });
      gsap.fromTo(".fog", { opacity: 0 }, { opacity: 0.4, duration: 3 });
      gsap.fromTo(logoRef.current, { scale: 0.8, opacity: 0 }, { scale: 1, opacity: 1, duration: 2.5 });

      // Mouse parallax
      const handleMove = (e: MouseEvent) => {
        const x = (e.clientX / window.innerWidth - 0.5) * 20;
        const y = (e.clientY / window.innerHeight - 0.5) * 20;
        gsap.to(".grid", { x: x, y: y, duration: 0.6, ease: "power2.out" });
        gsap.to(".fog", { x: -x * 0.5, y: -y * 0.5, duration: 0.6, ease: "power2.out" });
        gsap.to(logoRef.current, { x: x * 0.3, y: y * 0.3, duration: 0.6, ease: "power2.out" });
      };
      window.addEventListener("mousemove", handleMove);
      return () => window.removeEventListener("mousemove", handleMove);
    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <div
      ref={containerRef}
      style={{
        position: "relative",
        width: "100vw",
        height: "100vh",
        overflow: "hidden",
        background: "radial-gradient(circle at 50% 50%, #0a0a0a, #000)"
      }}
    >
      <GridLayer className="grid" />
      <FogLayer className="fog" />
      <LogoLayer ref={logoRef} />
    </div>
  );
}
